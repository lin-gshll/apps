/**
 * Created by jerry on 2017/4/14.
 */
import Vue from 'vue'

export let bus = new Vue()
